
gprof2dot.py is a Python script to convert the output from many
profilers into a dot graph.


